package com.example.staggered_recycler;

public class Data {
    Integer imagesResources;

    public Data(Integer imagesResources) {
        this.imagesResources = imagesResources;
    }

    public Integer getImagesResources() {
        return imagesResources;

    }

    public void setImagesResources(Integer imagesResources) {
        this.imagesResources = imagesResources;
    }


}
