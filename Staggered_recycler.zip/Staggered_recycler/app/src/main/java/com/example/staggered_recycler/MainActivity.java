package com.example.staggered_recycler;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;

import android.os.Bundle;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    DataAdapter dataAdapter;
    StaggeredGridLayoutManager staggeredGridLayoutManager;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        recyclerView = findViewById(R.id.recycler);

        List<Data> datalist = new ArrayList<>();
        datalist.add(new Data(R.drawable.a));
        datalist.add(new Data(R.drawable.b));
        datalist.add(new Data(R.drawable.c));
        datalist.add(new Data(R.drawable.d));
        datalist.add(new Data(R.drawable.e));
        datalist.add(new Data(R.drawable.f));
        datalist.add(new Data(R.drawable.g));
        datalist.add(new Data(R.drawable.h));
        datalist.add(new Data(R.drawable.a));
        datalist.add(new Data(R.drawable.b));
        datalist.add(new Data(R.drawable.c));
        datalist.add(new Data(R.drawable.d));
        datalist.add(new Data(R.drawable.e));
        datalist.add(new Data(R.drawable.f));
        datalist.add(new Data(R.drawable.g));
        datalist.add(new Data(R.drawable.h));
        datalist.add(new Data(R.drawable.a));
        datalist.add(new Data(R.drawable.b));
        datalist.add(new Data(R.drawable.c));
        datalist.add(new Data(R.drawable.d));
        datalist.add(new Data(R.drawable.e));
        datalist.add(new Data(R.drawable.f));
        datalist.add(new Data(R.drawable.g));
        datalist.add(new Data(R.drawable.h));


        // set the recycler view
        RecyclerView.LayoutManager layoutManager = new StaggeredGridLayoutManager(3,StaggeredGridLayoutManager.VERTICAL);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setHasFixedSize(true);
        dataAdapter = new DataAdapter(this, datalist);
        recyclerView.setAdapter(dataAdapter);





    }
}